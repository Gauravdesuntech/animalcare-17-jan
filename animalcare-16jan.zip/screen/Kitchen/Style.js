import { StyleSheet} from "react-native";
const styles = StyleSheet.create({
fW:{fontWeight:'bold'},
uploadedImage:{ width: 35, height: 35},
borderColor:{ borderColor : "#ddd" ,} ,
})
export default styles;
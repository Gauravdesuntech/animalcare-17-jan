<<<<<<< HEAD
=======
//created by Dibyendu 

>>>>>>> de4a6c22111ede957b711942ef56237399a4582e
import TagMaster from "./TagMaster";
import AddTag from "./AddTag";
import TagList from "./TagList";
import AddTagGroup from "./AddTagGroup";
import TagGroupList from "./TagGroupList";
import TagAssign from "./TagAssign";

<<<<<<< HEAD
export { TagMaster, AddTag, TagList, AddTagGroup, TagGroupList, TagAssign };
=======
export { 
    TagMaster, AddTag, TagList, AddTagGroup, TagGroupList, TagAssign 
};
>>>>>>> de4a6c22111ede957b711942ef56237399a4582e

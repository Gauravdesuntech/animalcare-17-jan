import SwipeGesture from './swipe-gesture';

export default SwipeGesture